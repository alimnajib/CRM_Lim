import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { PelangganModule } from './pelanggan.module';
import { PerusahaanModule } from './perusahaan/perusahaan.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      envFilePath: ['.env.local', '.env'],
      isGlobal: true,
    }),
    MongooseModule.forRoot(process.env.MONGO_URL!),
    PelangganModule,
    PerusahaanModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
