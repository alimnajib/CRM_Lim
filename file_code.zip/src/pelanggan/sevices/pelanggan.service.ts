import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Pelanggan } from '../schema/pelanggan.schema';
import { Model } from 'mongoose';

@Injectable()
export class PelangganService {
  constructor(
    @InjectModel(Pelanggan.name)
    private pelangganModel: Model<Pelanggan>,
  ) {}
  async savePelanggan(): Promise<any> {
    try {
      const pelanggan = {
        namaLengkap: 'Muh. Alim Najib ks',
        email: 'alimnajib09@email.com',
        noHp: '089646579492',

      };
      await new this.pelangganModel(pelanggan).save();
      return pelanggan;
    } catch (error) {
      console.error(error);
    }
  }

  async dataHp(noHp: string): Promise<any> {
    return await this.pelangganModel.findOne({ noHp }).exec();
  }

  async dataSemuaHp(): Promise<any> {
    return await this.pelangganModel.find().exec();
  }
}
